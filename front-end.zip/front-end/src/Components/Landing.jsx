import React from 'react'

function Landing() {
  return (
    <div className='bg-mainBlack text-txt1   '>
        <h1>with Security</h1>
        <div>
            <h2>keep your identity  <span className='text-customGreen '> safe</span></h2>

        </div>
    </div>
  )
}

export default Landing